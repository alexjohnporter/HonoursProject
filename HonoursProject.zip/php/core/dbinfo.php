<?php
//Header('Content-Type: application/json; charset=UTF8');
$username="root";
$password="";
$database="museums";
?>