-- phpMyAdmin SQL Dump
-- version 4.2.0
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 04, 2015 at 07:32 PM
-- Server version: 5.6.15-log
-- PHP Version: 5.5.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `museums`
--

-- --------------------------------------------------------

--
-- Table structure for table `header`
--

CREATE TABLE IF NOT EXISTS `header` (
`hdrID` int(11) NOT NULL,
  `hdrTxt` varchar(80) COLLATE utf8_bin NOT NULL,
  `hdrImg` varchar(80) COLLATE utf8_bin DEFAULT NULL,
  `hdrDesc` varchar(300) COLLATE utf8_bin DEFAULT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=2 ;

--
-- Dumping data for table `header`
--

INSERT INTO `header` (`hdrID`, `hdrTxt`, `hdrImg`, `hdrDesc`) VALUES
(1, 'Glasgow Museums', 'http://i.imgur.com/xn520M9.jpg', 'Test site for Glasgow Museums');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE IF NOT EXISTS `items` (
`itemID` int(11) NOT NULL,
  `itemName` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `itemTxt` varchar(300) COLLATE utf8_bin DEFAULT NULL,
  `AddressOne` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `AddressTwo` varchar(40) COLLATE utf8_bin DEFAULT NULL,
  `Postcode` varchar(8) COLLATE utf8_bin DEFAULT NULL,
  `itemImgLarge` varchar(100) COLLATE utf8_bin NOT NULL,
  `itemImgSmall` varchar(100) COLLATE utf8_bin NOT NULL,
  `timeID` int(1) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=10 ;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`itemID`, `itemName`, `itemTxt`, `AddressOne`, `AddressTwo`, `Postcode`, `itemImgLarge`, `itemImgSmall`, `timeID`) VALUES
(1, 'Kelvingrove Art Gallery and Museum', 'Kelvingrove Art Gallery and Museum houses one of Europe''s great art collections. It is amongst the top three free-to-enter visitor attractions in Scotland and one of the most visited museums in the United Kingdom outside of London.', 'Kelvingrove Art Gallery and Museum', '1397-1403 Argyle Street', 'G3 8AG', 'http://i.imgur.com/oQqHSG9.jpg', 'http://i.imgur.com/oQqHSG9.jpg', 1),
(2, 'Riverside Museum', 'This is the item description for the Riverside Museum', 'Riverside Museum', '100 Pointhouse Place', 'G3 8RS', 'http://i.imgur.com/mylI2xX.jpg', 'http://i.imgur.com/mylI2xX.jpg', 1),
(3, 'The Burrell Collection', 'Within the heart of Pollok Country Park, this award-winning building houses a unique collection in a beautiful woodland setting. The collection is one of the greatest ever created by one person, comprising over 8000 objects.', 'Pollok Country Park', ' 2060 Pollokshaws Road', 'G43 1AT', 'http://i.imgur.com/URPKINQ.png', 'http://i.imgur.com/URPKINQ.png', 1),
(4, 'Gallery of Modern Art', 'Situated in the heart of the City Centre, GoMA is Scotland''s most visited modern art gallery displaying work that highlights the interests, influences and working methods of artists from around the world.', 'Royal Exchange Square', 'Glasgow', 'G1 3AH', 'http://i.imgur.com/I9p3vZn.jpg', 'http://i.imgur.com/I9p3vZn.jpg', 1),
(5, 'People''s Palace and Winter Gardens', 'The People''s Palace, located in the historic Glasgow Green, is home to a collection of historical artifacts, photographs, prints and film, which gives an unrivalled insight into how Glaswegians lived, work and played from the 18th to the 20th century.', 'Glasgow Green', 'Glasgow', 'G40 1AT', 'http://i.imgur.com/eDTbvBm.jpg', 'http://i.imgur.com/eDTbvBm.jpg', 2),
(6, 'St Mungo Museum', 'St Mungo Description', '2 Castle Street', 'Glasgow', 'G4 0RH', 'http://i.imgur.com/4DJRVT8.jpg', 'http://i.imgur.com/4DJRVT8.jpg', 2),
(7, 'Provand''s Lordship', 'Provand Lordship Description', '3 Castle Street', 'Glasgow', 'G4 0RB', 'http://i.imgur.com/3WHcHcT.jpg', 'http://i.imgur.com/3WHcHcT.jpg', 2),
(8, 'Scotland Street School Museum', 'Sct Street School is a must-see for fans of Charles Rennie Mackintosh and tells the story of education in Scotland from the late 19th century to the late 20th century.', '225 Scotland Street', 'Glasgow', 'G5 8QB ', 'http://i.imgur.com/YhEm2V1.jpg', 'http://i.imgur.com/YhEm2V1.jpg', 2),
(9, 'Glasgow Museums Resource Centre', 'Book a tour to visit the extraordinary store for Glasgow Museums'' vast collection. Come and see our Archaeology, Art & Painting, Arms & Armour, Natural History, Transport & Technology and World Cultures collections. ', '200 Woodhead Road', 'South Nitshill Industrial Estate', 'G53 7NN', 'http://i.imgur.com/shTmzBi.jpg', 'http://i.imgur.com/shTmzBi.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
`reviewID` int(11) NOT NULL,
  `reviewIP` int(11) NOT NULL,
  `reviewerName` varchar(25) COLLATE utf8_bin NOT NULL,
  `reviewerEmail` varchar(50) COLLATE utf8_bin NOT NULL,
  `reviewComment` varchar(500) COLLATE utf8_bin NOT NULL,
  `reviewDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `itemID` int(11) NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=13 ;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`reviewID`, `reviewIP`, `reviewerName`, `reviewerEmail`, `reviewComment`, `reviewDate`, `itemID`) VALUES
(12, 1451433402, 'sdfs', 'sdf', 'sdf', '2015-02-04 18:27:52', 3),
(11, 1451433402, 'Alexander Porter', 'alexporter1992@live.co.uk', 'Amazing Museum', '2015-02-04 17:35:07', 2),
(10, 1451433402, 'sdfsd', 'sdfsd', 'sdf', '2015-02-04 16:19:45', 4),
(9, 1451433402, 'fgfg', 'hfghf', 'fghfgh', '2015-02-04 16:18:09', 1);

-- --------------------------------------------------------

--
-- Table structure for table `timing`
--

CREATE TABLE IF NOT EXISTS `timing` (
`timeID` int(11) NOT NULL,
  `Mon` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `MonClose` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `Tues` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `TuesClose` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `Wed` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `WedClose` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `Thurs` varchar(5) COLLATE utf8_bin NOT NULL,
  `ThursClose` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `Fri` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `FriClose` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `Sat` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `SatClose` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `Sun` varchar(5) COLLATE utf8_bin DEFAULT NULL,
  `SunClose` varchar(5) COLLATE utf8_bin DEFAULT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=3 ;

--
-- Dumping data for table `timing`
--

INSERT INTO `timing` (`timeID`, `Mon`, `MonClose`, `Tues`, `TuesClose`, `Wed`, `WedClose`, `Thurs`, `ThursClose`, `Fri`, `FriClose`, `Sat`, `SatClose`, `Sun`, `SunClose`) VALUES
(1, '10:00', '17:00', '10:00', '17:00', '10:00', '17:00', '10:00', '17:00', '10:00', '17:00', '10:00', '17:00', '10:00', '17:00'),
(2, 'Close', 'Close', '10:00', '17:00', '10:00', '17:00', '10:00', '17:00', '10:00', '17:00', '10:00', '17:00', '10:00', '17:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `header`
--
ALTER TABLE `header`
 ADD PRIMARY KEY (`hdrID`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
 ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
 ADD PRIMARY KEY (`reviewID`);

--
-- Indexes for table `timing`
--
ALTER TABLE `timing`
 ADD PRIMARY KEY (`timeID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `header`
--
ALTER TABLE `header`
MODIFY `hdrID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
MODIFY `itemID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
MODIFY `reviewID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `timing`
--
ALTER TABLE `timing`
MODIFY `timeID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
