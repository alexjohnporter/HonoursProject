<?php
include 'dbinfo.php';
Header('Content-Type: application/json; charset=UTF8');
$name = isset($_POST['reviewer-name']) ? $_POST['reviewer-name'] : "";
$email = isset($_POST['reviewer-email']) ? $_POST['reviewer-email'] : "";
$comment = isset($_POST['review-comment']) ? $_POST['review-comment'] : "";
$ip = isset($_POST['reviewer-ip']) ? $_POST['reviewer-ip'] : "";
$itemID = isset($_POST['review-item-id']) ? $_POST['review-item-id'] : "";
$ip = ip2long($ip);
//sanitize inputs!!!!!!!!!!!!!!!!!!!!!!
function sanitizeForm($field) {
    // Sanitize e-mail address
    $field=filter_var($field, FILTER_SANITIZE_EMAIL);
    // Validate e-mail address
    if(filter_var($field, FILTER_VALIDATE_EMAIL)) {
        return TRUE;
    } else {
        return FALSE;
    }
}

//ensure all data is collected
//$formCheck = sanitizeForm($name,$email,$comment,$ip,$itemID,$ip);
//if($formCheck == false){
  //  '{"message": "Invalid details"}';
//}else{
if (  !empty($name) && !empty($email) && !empty($comment) && !empty($ip) && !empty($itemID)) {

    try {
        $dbh = new PDO("mysql:host=localhost;dbname=$database", $username, $password);
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // SQL errors will not be silent

    } catch (PDOException $e) {
        print "Error!: " . $e->getMessage() . "<br/>";
        die();
    }
    function checkReviewExists($dbh, $ip, $itemID)
    {
        $stmt = $dbh->prepare("SELECT reviewID FROM reviews WHERE reviewIP = $ip AND itemID=$itemID");
        $stmt->execute();
        $result = $stmt->rowCount();
        if ($result > 0) {
            return false;
        } else {
            return true;
        }
    }

    $reviewExists = checkReviewExists($dbh, $ip, $itemID);

    if (!$reviewExists) {
        echo '{"message": "You have already left a review"}';
    } else {
        echo '{"message": "Review uploaded"}';
        $stmt = $dbh->prepare("INSERT INTO reviews (reviewIP, reviewerName, reviewerEmail, reviewComment,itemID) VALUES (:ip, :name, :email, :comment, :itemID);");
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':comment', $comment);
        $stmt->bindParam(':ip', $ip);
        $stmt->bindParam(':itemID', $itemID);
        $stmt->execute();
        $dbh = null;
    }
}else{
    echo '{"message": "No data collected"}';
}
//}





